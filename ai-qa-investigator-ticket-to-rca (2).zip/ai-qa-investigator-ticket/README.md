# AI QA Investigator — Production Ticket to RCA MVP

This version changes the workflow from **manual field entry** to **ticket-first investigation**.

## Product flow
1. Manual tester pastes a customer production ticket.
2. `/api/investigate` sends the ticket to the OpenAI Responses API using a server-side API key.
3. The model reconstructs incident details: summary, feature, severity, environment, status, impact, frequency, steps, expected/actual, timeline and useful identifiers.
4. The same response generates a probable RCA, evidence, missing information, next checks and a reproduction strategy.
5. The UI keeps ground-truth-like evidence separate from inference.

## Deploy
- Upload this folder/zip to Vercel.
- Add `OPENAI_API_KEY` as a server-side environment variable.
- Optionally set `OPENAI_MODEL` (default is `gpt-6-luna`).
- Redeploy.

## Demo
The UI includes 10 synthetic production tickets for demos. Do not paste real secrets or unnecessary customer PII into a public demo.

## Important
This is an AI-assisted investigation MVP, not an autonomous RCA system. Generated RCA must be validated against logs, traces, data and other objective evidence.
