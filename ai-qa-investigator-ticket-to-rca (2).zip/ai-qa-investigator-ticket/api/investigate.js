import OpenAI from "openai";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const model = process.env.OPENAI_MODEL || "gpt-6-luna";

const schema = {
  type: "object",
  additionalProperties: false,
  properties: {
    ticket_summary: { type: "string" },
    feature: { type: "string" },
    severity: { type: "string" },
    environment: { type: "string" },
    incident_status: { type: "string" },
    customer_impact: { type: "string" },
    frequency: { type: "string" },
    steps: { type: "array", items: { type: "string" } },
    expected: { type: "string" },
    actual: { type: "string" },
    timeline: { type: "array", items: { type: "string" } },
    useful_identifiers: { type: "array", items: { type: "string" } },
    evidence_extracted: { type: "array", items: { type: "string" } },
    probable_rca: { type: "string" },
    confidence: { type: "integer", minimum: 0, maximum: 100 },
    failure_category: { type: "array", items: { type: "string" } },
    evidence: { type: "array", items: { type: "string" } },
    unknown: { type: "string" },
    next_checks: { type: "array", items: { type: "string" } },
    reproduction_strategy: { type: "array", items: { type: "string" } },
    rca_wording: { type: "string" }
  },
  required: [
    "ticket_summary","feature","severity","environment","incident_status",
    "customer_impact","frequency","steps","expected","actual","timeline",
    "useful_identifiers","evidence_extracted","probable_rca","confidence",
    "failure_category","evidence","unknown","next_checks",
    "reproduction_strategy","rca_wording"
  ]
};

function cleanTicket(ticket) {
  return String(ticket || "").trim().slice(0, 30000);
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: "OPENAI_API_KEY is not configured on the server." });

  const ticket = cleanTicket(req.body?.ticket);
  if (!ticket) return res.status(400).json({ error: "Paste a production ticket first." });

  try {
    const instructions = `You are an expert production-incident investigator assisting manual QA engineers.

Your job is to do TWO things from a single customer production ticket:
1) reconstruct the structured incident details that a QA engineer would otherwise have to enter manually;
2) investigate the likely root cause and explain what evidence is still needed to confirm it.

Rules:
- Use only information in the ticket. Never invent logs, HTTP codes, database values, timestamps, deployments, or customer facts.
- Put missing information in a field as "Not provided in ticket" or an empty array where appropriate.
- Distinguish OBSERVED FACTS from INFERENCES.
- The RCA is a hypothesis unless the ticket contains enough direct evidence to confirm it. Keep confidence calibrated.
- For non-reproducible incidents, explicitly reason about state, timing, concurrency, retries, caching, data shape, configuration, external dependencies, and deployment/version differences.
- Extract useful identifiers only when present (incident IDs, order/reservation IDs, request IDs, correlation IDs, timestamps). Do not invent them.
- Do not repeat secrets, passwords, API keys, authentication tokens, payment card data, or unnecessary personal information. Summarize sensitive details as [REDACTED].
- Steps should be reconstructed from the ticket into the clearest sequence possible. If steps are incomplete, say so.
- Reproduction strategy should be practical and should target the conditions suggested by the evidence.
- The suggested RCA wording must be suitable for a Jira/Azure DevOps incident update and must not overstate certainty.

TICKET:\n${ticket}`;

    const response = await client.responses.create({
      model,
      store: false,
      input: instructions,
      text: { format: { type: "json_schema", name: "qa_production_investigation", strict: true, schema } }
    });

    return res.status(200).json(JSON.parse(response.output_text));
  } catch (e) {
    return res.status(500).json({ error: e?.message || "Investigation failed" });
  }
}
